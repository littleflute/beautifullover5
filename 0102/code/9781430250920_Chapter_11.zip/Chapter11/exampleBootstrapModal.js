// JavaScript Document
$(document).ready(function(e) {
	$(document).off('.data-api');
	$('#launchButton').click(function(){
		$('#myModal').modal({ show: true}); //if you comment this out the modal will not work
	});
   
});