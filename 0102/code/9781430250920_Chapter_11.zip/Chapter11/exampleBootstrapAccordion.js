// JavaScript Document
$(document).ready(function(e) {
   $(document).off('.data-api');
		
	
	$('#header1').click(function(){
		$('#collapseOne').collapse('toggle');
	});


	$('#header2').click(function(){
		$('#collapseTwo').collapse('toggle');
	});

});