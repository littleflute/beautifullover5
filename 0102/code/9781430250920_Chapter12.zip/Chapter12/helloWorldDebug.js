function startUp(){
	console.log("Hello World")
	debugger;
}

exports.startup = startUp;