var debugMod = require("./helloWorldDebug");
	debugMod.startup();
