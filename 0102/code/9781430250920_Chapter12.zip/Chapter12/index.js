var server = require("./httpServerModule");

server.startup();