css={
  // hide elements 
  hide:'hide', 
  // indicator for support of dynamic scripting
  // will be added to the body element
  supported:'dynamic'
}
