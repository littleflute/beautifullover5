<ul id="nav">
	<li><a href="index.php">Home</a></li>
	<li><a href="products.php">Products</a>
		<ul>
			<li><a href="cms.php">CMS solutions</a>
				<ul>
					<li><a href="minicms.php">Mini CMS</a></li>
					<li><a href="ncc1701d.php">Enterprise CMS</a></li>
				</ul>
			</li>
			<li><a href="portal.php">Company Portal</a></li>
			<li><a href="mailserver.php">eMail Solutions</a>
				<ul>
					<li><a href="privatemail.php">Private POP3/SMTP</a></li>
					<li><a href="lists.php">Listservers</a></li>
				</ul>
			</li>
		</ul>
	</li>
	<li><a href="services.php">Services</a>
		<ul>
			<li><a href="training.php">Employee Training</a></li>
			<li><a href="audits.php">Auditing</a></li>
			<li><a href="bulkmail.php">Bulk sending/email campaigns</a></li>
		</ul>
	</li>
	<li><a href="pricing.php">Pricing</a></li>
	<li><a href="about_us.php">About Us</a>
		<ul>
			<li><a href="our_offices.php">Our offices</a></li>
			<li><a href="our_people.php">Our people</a></li>
			<li><a href="vacancies.php">Jobs</a></li>
			<li><a href="partners.php">Industry Partners</a></li>
		</ul>
	</li>
	<li><a href="contact.php">Contact Us</a>
		<ul>
			<li><a href="snail.php">Postal Addresses</a></li>
			<li><a href="callback.php">Arrange Callback</a></li>
		</ul>
	</li>
</ul>
